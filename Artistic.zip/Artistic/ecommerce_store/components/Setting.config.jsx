export const setting = {
    ip: 'http://192.168.113.6:5291',
   
  };