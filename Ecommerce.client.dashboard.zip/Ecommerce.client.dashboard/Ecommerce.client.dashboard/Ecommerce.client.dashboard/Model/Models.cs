﻿namespace Ecommerce.client.dashboard.Model
{

    public class SignupModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class Item
    {
        public int Qty { get; set; }
        public int Pid { get; set; }
        public int OrderId { get; set; }
        public int price { get; set; }
    }

    public class OrderSummary
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public string Address { get; set; }
        public decimal TotalPrice { get; set; }
        public string Status { get; set; }
    }


    public class OrderModel
    {
        public string Username { get; set; }
        public string Address { get; set; }
        public string phone_no { get; set; }


        public List<Item> Items { get; set; }  // Array of items
    }

    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
    public class Customer
    {
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Country { get; set; }
    }
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
    }
    public class Order
    {
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal Total { get; set; }
        public string Status { get; set; }

        // Navigation property
        public Customer Customer { get; set; }

        // Collection navigation property (for order items)
        public ICollection<OrderItem> OrderItems { get; set; }
    }
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }

        // Navigation properties
        public Order Order { get; set; }
        public Product Product { get; set; }
    }

    public class UserDetail
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PinCode { get; set; }
    }

    public class OrderItemReact
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
    public class ProductToShow
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Category { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public List<Image> Images { get; set; } = new List<Image>();
        public string SKU { get; set; }
        public string Size { get; set; }
        public string Color { get; set; }
        public string Fabric { get; set; }
        public string Season { get; set; }
        public string Description { get; set; }
    }

    public class Image
    {
        public string Url { get; set; }
    }


    public class OrderToPush
    {
        public List<OrderItemReact> Items { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }



}
