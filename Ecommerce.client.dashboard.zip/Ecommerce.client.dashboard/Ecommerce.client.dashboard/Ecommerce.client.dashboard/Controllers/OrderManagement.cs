﻿using Ecommerce.client.dashboard.DB_Context;
using Ecommerce.client.dashboard.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Ecommerce.client.dashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderManagement : ControllerBase
    {
       // private readonly EcommerceDbContext _context;

        string filePath = @"C:\Temp\Agent.txt";
        // GET: api/<OrderManagement>
        [HttpGet]
        public List<Product> Get()
        {
            if (!System.IO.File.Exists(filePath))
            {
                return new List<Product>();
            }

            DataLinkLayer _productRepository = new DataLinkLayer();
            var products = _productRepository.GetProductsNotInOrders();
            return products;
        }


        // GET: api/OrderManagement
        [HttpGet("GetAllOrders")]
        public IActionResult GetAllOrders()
        {
            //try
            //{
            //    var orders = _context.Orders.ToList();
            //    if (orders == null || !orders.Any())
            //    {
            //        return NotFound("No orders found.");
            //    }
            //    return Ok(orders);
            //}
            //catch (Exception ex)
            //{
            //    return StatusCode(500, "An error occurred while retrieving orders. " + ex.Message);
            //}
            return StatusCode(500, "An error occurred while deleting the order. " + "HY");
        }

        [HttpPost("PushOrder")]
        public IActionResult PushOrder([FromBody] OrderToPush order)
        {
            // Here you would handle the order processing logic, e.g., save to database
            return Ok("Order received successfully.");
        }

        // GET api/OrderManagement/5
        [HttpGet("{id}")]
        public IActionResult GetOrderById(int id)
        {
            //try
            //{
            //    var order = _context.Orders.FirstOrDefault(o => o.Id == id);
            //    if (order == null)
            //    {
            //        return NotFound($"Order with ID {id} not found.");
            //    }
            //    return Ok(order);
            //}
            //catch (Exception ex)
            //{
            //    return StatusCode(500, "An error occurred while retrieving the order. " + ex.Message);
            //}
            return StatusCode(500, "An error occurred while deleting the order. " + "HY");
        }

        // POST api/OrderManagement
        [HttpPost]
        public IActionResult CreateOrder([FromBody] Order order)
        {
            //if (order == null)
            //{
            //    return BadRequest("Order data is null.");
            //}

            //try
            //{
            //    _context.Orders.Add(order);
            //    _context.SaveChanges();
            //    return CreatedAtAction(nameof(GetOrderById), new { id = order.Id }, order);
            //}
            //catch (Exception ex)
            //{
            //    return StatusCode(500, "An error occurred while creating the order. " + ex.Message);
            //}
            return StatusCode(500, "An error occurred while deleting the order. " + "HY");
        }

        // PUT api/OrderManagement/5
        [HttpPut("{id}")]
        public IActionResult UpdateOrder(int id, [FromBody] Order orderUpdate)
        {
            //if (orderUpdate == null || orderUpdate.Id != id)
            //{
            //    return BadRequest("Order ID mismatch or bad data.");
            //}

            //var order = _context.Orders.FirstOrDefault(o => o.Id == id);
            //if (order == null)
            //{
            //    return NotFound($"Order with ID {id} not found.");
            //}

            //try
            //{
            //    order.ProductId = orderUpdate.ProductId;
            //    order.Quantity = orderUpdate.Quantity;
            //    order.Status = orderUpdate.Status;
            //    _context.SaveChanges();
            //    return NoContent();
            //}
            //catch (Exception ex)
            //{
            //    return StatusCode(500, "An error occurred while updating the order. " + ex.Message);
            //}
            return StatusCode(500, "An error occurred while deleting the order. " + "HY");
        }

        [HttpGet("ordersummary")]
        public async Task<IActionResult> GetOrderSummary([FromQuery] string customerId)
        {
            DataLinkLayer d = new DataLinkLayer();
            var orderSummary = await d.GetOrderSummaryByCustomerIdAsync(customerId);

            if (orderSummary == null || !orderSummary.Any())
            {
                return NotFound();
            }

            return Ok(orderSummary);
        }

        [HttpPost("PlaceOrder")]
        public IActionResult PlaceOrder([FromBody] OrderModel model)
        {
            if (model == null)
            {
                return BadRequest("Order data is required.");
            }

            // Validate the data
            if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Address))
            {
                return BadRequest("Username and address are required.");
            }

            if (model.Items == null || model.Items.Count == 0)
            {
                return BadRequest("At least one item is required.");
            }

            // Process the order (e.g., save to the database)
            DataLinkLayer dl = new DataLinkLayer();

            // Example logic: save the order and items to the database
            dl.SaveOrder(model);

            // Return a success response
            return CreatedAtAction(nameof(PlaceOrder), new { username = model.Username }, model);
        }

        // DELETE api/OrderManagement/5
        [HttpDelete("{id}")]
        public IActionResult DeleteOrder(int id)
        {
            //var order = _context.Orders.FirstOrDefault(o => o.Id == id);
            //if (order == null)
            //{
            //    return NotFound($"Order with ID {id} not found.");
            //}

            //try
            //{
            //    _context.Orders.Remove(order);
            //    _context.SaveChanges();
            //    return NoContent();
            //}
            //catch (Exception ex)
            //{
            //    return StatusCode(500, "An error occurred while deleting the order. " + ex.Message);
            //}
            return StatusCode(500, "An error occurred while deleting the order. " +"HY");
        }
        
        
    }
}
