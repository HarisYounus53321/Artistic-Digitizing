﻿using Ecommerce.client.dashboard.Model;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Ecommerce.client.dashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductManagement : ControllerBase
    {
        private readonly string _connectionString;

        public ProductManagement(IConfiguration configuration)
        {
            string connectionString = "00";
            if (System.IO.File.Exists("C:\\temp\\Config.txt"))
            {
                StreamReader reader = new StreamReader("C:\\temp\\Config.txt");
                string instance = reader.ReadLine();
                connectionString = instance;
            }
            else
            {
                connectionString = "Data Source=X230\\SOLVER; database= ecommerce_store; user id=sa; password=123456;";


            }
            _connectionString = connectionString;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductToShow>>> GetProducts()
        {
            var products = new Dictionary<int, ProductToShow>();

            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                string query = @"
            SELECT
                p.Id,
                p.Name,
                p.Category,
                p.Price,
                p.Stock,
                p.SKU,
                p.Size,
                p.Color,
                p.Fabric,
                p.Season,
                p.Description,
                i.Url AS ImageUrl
            FROM
                ProductsToShow p
            LEFT JOIN
                Images i ON p.Id = i.ProductId";

                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            int productId = reader.GetInt32(0);

                            if (!products.ContainsKey(productId))
                            {
                                var product = new ProductToShow
                                {
                                    Id = productId,
                                    Name = reader.GetString(1),
                                    Category = reader.GetInt32(2),
                                    Price = reader.GetDecimal(3),
                                    Stock = reader.GetInt32(4),
                                    SKU = reader.GetString(5),
                                    Size = reader.GetString(6),
                                    Color = reader.GetString(7),
                                    Fabric = reader.GetString(8),
                                    Season = reader.GetString(9),
                                    Description = reader.GetString(10)
                                };

                                products.Add(productId, product);
                            }

                            if (!reader.IsDBNull(11))
                            {
                                var image = new Image
                                {
                                    Url = reader.GetString(11)
                                };

                                products[productId].Images.Add(image);
                            }
                        }
                    }
                }
            }

            return Ok(products.Values);
        }

    }
}
