﻿using Ecommerce.client.dashboard.DB_Context;
using Ecommerce.client.dashboard.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Ecommerce.client.dashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Auth : ControllerBase
    {
        // GET: api/<Auth>
        [HttpGet("login")]
        public string LoginUser(string email,string passowrd)
        {
            DataLinkLayer d = new DataLinkLayer();
            if(d.ValidateUser(email, passowrd))
            {
                return "login in";
            }
            
            return "User or Password incorrent;";
        }

        

        // POST api/<Auth>
        [HttpPost("signUp")]
        public IActionResult Signup([FromBody] SignupModel model)
        {
            DataLinkLayer dl = new DataLinkLayer();
            if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Password))
                return BadRequest("Username and password are required");

            if (dl.UserExists(model.Username))
                return Conflict("Username already exists");

            dl.RegisterUser(model.Username, model.Password);

            return CreatedAtAction(nameof(Signup), new { username = model.Username }, model);
        }

        //[HttpPost("PushOrder")]
        //public string PushOreder([FromBody]  OrderToPush d)
        //{
        //    return "ok";
        //}

        // PUT api/<Auth>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<Auth>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
