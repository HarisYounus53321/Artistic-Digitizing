﻿using Ecommerce.client.dashboard.Model;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace Ecommerce.client.dashboard.DB_Context
{
    public class DataLinkLayer
    {
        string GetConnectionString()
        {
            string connectionString = "00";
            if (File.Exists("C:\\temp\\Config.txt"))
            {
                StreamReader reader = new StreamReader("C:\\temp\\Config.txt");
                string instance = reader.ReadLine();
                connectionString = instance;

            }
            else
            {
                connectionString = "Data Source=X230\\SOLVER; database=ecommerce_store ; user id=sa; password=123456;";


            }
            return connectionString;
        }
        private SqlDataReader GetResult(string query)
        {
            string connectionString = "00";
            if (File.Exists("C:\\temp\\Config.txt"))
            {
                StreamReader reader = new StreamReader("C:\\temp\\Config.txt");
                string instance = reader.ReadLine();
                connectionString = instance;
            }
            else
            {
                connectionString = "Data Source=X230\\SOLVER; database= ecommerce_store; user id=sa; password=123456;";


            }
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();


            SqlCommand com = new SqlCommand(query, con);
            SqlDataReader dr = com.ExecuteReader();

            return dr;


        }
        private int SetResult(string query)
        {
            string connectionString = "00";
            if (File.Exists("C:\\Dinoload\\Config.txt"))
            {
                StreamReader reader = new StreamReader("C:\\temp\\Config.txt");
                string instance = reader.ReadLine();
                connectionString = instance;
            }
            else
            {
                connectionString = "Data Source=X230\\SOLVER; database= ecommerce_store ; user id=sa; password=123456;";
            }
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand com = new SqlCommand(query, con);
            int result = com.ExecuteNonQuery();

            return result;


        }
        public List<Product> GetProductsNotInOrders()
        {
            string query = @"
            SELECT p.*
            FROM products p
            LEFT JOIN order_items oi ON p.product_id = oi.product_id
            WHERE oi.product_id IS NULL;
        ";

            List<Product> products = new List<Product>();

            using (SqlDataReader dr = GetResult(query))
            {
                while (dr.Read())
                {
                    Product product = new Product
                    {
                        ProductId = Convert.ToInt32(dr["product_id"]),
                        ProductName = dr["product_name"].ToString(),
                        ProductDescription = dr["product_description"].ToString(),
                        Price = Convert.ToDecimal(dr["price"]),
                        Stock = Convert.ToInt32(dr["stock"])
                    };

                    products.Add(product);
                }
            }

            return products;
        }

        public bool UserExists(string username)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var command = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username", connection);
                command.Parameters.AddWithValue("@Username", username);

                connection.Open();
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        public void RegisterUser(string username, string password)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var command = new SqlCommand("INSERT INTO Users (Username, PasswordHash) VALUES (@Username, @PasswordHash)", connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@PasswordHash", HashPassword(password));

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public bool ValidateUser(string username, string password)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var command = new SqlCommand("SELECT PasswordHash FROM Users WHERE Username = @Username", connection);
                command.Parameters.AddWithValue("@Username", username);

                connection.Open();
                var passwordHash = command.ExecuteScalar() as string;

                return passwordHash != null && VerifyPassword(password, passwordHash);
            }
        }

        private bool VerifyPassword(string password, string hashedPassword)
        {
            var hash = HashPassword(password);
            return hash == hashedPassword;
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
        public void SaveOrder(OrderModel model)
        {
            using (SqlConnection conn = new SqlConnection(GetConnectionString()))
            {
                conn.Open();

                // Start a transaction
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    int id = 0;
                    try
                    {

                        SqlDataReader dr = GetResult("select id from Users where Username='"+model.Username+"'");
                        if(dr.Read())
                        {
                            id = dr.GetInt32(0);
                            try
                            {
                                // Step 1: Insert into orders table and get the order_id
                                string insertOrderQuery = @"
                    INSERT INTO orders (customer_id, address, phone_no, total, status) 
                    OUTPUT INSERTED.order_id
                    VALUES (@CustomerId, @Address, @PhoneNo, @Total, @Status)";

                                SqlCommand orderCmd = new SqlCommand(insertOrderQuery, conn, transaction);
                                orderCmd.Parameters.AddWithValue("@CustomerId", id); // Assuming you have customer_id in the model
                                orderCmd.Parameters.AddWithValue("@Address", model.Address);
                                orderCmd.Parameters.AddWithValue("@PhoneNo", model.phone_no); // Assuming phone number is included in the model
                                orderCmd.Parameters.AddWithValue("@Total", 0); // Assuming total is included in the model
                                orderCmd.Parameters.AddWithValue("@Status", "Pending");

                                int orderId = (int)orderCmd.ExecuteScalar();

                                // Step 2: Insert each item into order_items table
                                foreach (var item in model.Items)
                                {
                                    string insertItemQuery = @"
                        INSERT INTO order_items (order_id, product_id, quantity, price) 
                        VALUES (@OrderId, @ProductId, @Quantity, @Price)";

                                    SqlCommand itemCmd = new SqlCommand(insertItemQuery, conn, transaction);
                                    itemCmd.Parameters.AddWithValue("@OrderId", orderId);
                                    itemCmd.Parameters.AddWithValue("@ProductId", item.Pid);
                                    itemCmd.Parameters.AddWithValue("@Quantity", item.Qty);
                                    itemCmd.Parameters.AddWithValue("@Price", item.price); // Assuming price is included in the item model

                                    itemCmd.ExecuteNonQuery();
                                }

                                // Commit the transaction
                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {
                                // Rollback the transaction if any error occurs
                                transaction.Rollback();
                                throw new Exception("Error saving order: " + ex.Message);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // Rollback the transaction if any error occurs
                        transaction.Rollback();
                        throw new Exception("Error saving order: " + ex.Message);
                    }
                   
                }
            }
        }

        public async Task<IEnumerable<OrderSummary>> GetOrderSummaryByCustomerIdAsync(string User)
        {
            var orderSummaries = new List<OrderSummary>();
            int id = 0;
            SqlDataReader dr = GetResult("select id from Users where Username='" + User + "'");
            if (dr.Read())
            {
                id = dr.GetInt32(0);
            }


                using (var connection = new SqlConnection(GetConnectionString()))
            {

                await connection.OpenAsync();
                using (var command = new SqlCommand(@"
                SELECT 
                    o.order_id, 
                    o.order_date, 
                    o.address, 
                    SUM(oi.price) AS total_price, 
                    o.status
                FROM 
                    orders AS o
                INNER JOIN 
                    Users AS u ON o.customer_id = u.Id
                INNER JOIN 
                    order_items AS oi ON o.order_id = oi.order_id
                WHERE 
                    o.customer_id = @CustomerId
                GROUP BY 
                    o.order_id, 
                    o.order_date, 
                    o.address, 
                    o.status
                ORDER BY 
                    o.order_id;", connection))
                {
                    command.Parameters.Add(new SqlParameter("@CustomerId", SqlDbType.Int) { Value = id });

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            orderSummaries.Add(new OrderSummary
                            {
                                OrderId = reader.GetInt32(reader.GetOrdinal("order_id")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("order_date")),
                                Address = reader.GetString(reader.GetOrdinal("address")),
                                TotalPrice = reader.GetDecimal(reader.GetOrdinal("total_price")),
                                Status = reader.GetString(reader.GetOrdinal("status"))
                            });
                        }
                    }
                }
            }

            return orderSummaries;
        }
    }
}
